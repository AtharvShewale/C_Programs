#include<stdio.h>



int main()
{
    char Arr[20];

    printf("Enter string : \n");
    scanf("%[^'\n']s",Arr);
    
    return 0;
}
